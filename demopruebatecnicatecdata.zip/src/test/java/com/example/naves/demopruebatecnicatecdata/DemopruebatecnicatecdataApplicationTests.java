package com.example.naves.demopruebatecnicatecdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemopruebatecnicatecdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
